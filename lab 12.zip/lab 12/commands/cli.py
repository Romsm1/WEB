import typer
from .hello import hello_app

app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode='rich'
)

@app.callback()
def callback():
    """
    Some CLI management commands.
    """
    pass

app.add_typer(hello_app)