API_TOKENS = frozenset({
    "aa423",
    "t0k3n"
})