API_TOKENS = frozenset({
    "aa423",
    "t0k3n"
})

USERS = {
    "admin": "admin",
    "user": "user",
    "Amentia": "423423",
    "ivan": "zolo"
}